 /**
  *******************************************************************************
  * @file    VentiTwoProto.h
  * @author  Evgeny KIRSHIN
  * @version V1.0
  * @date    2020-03-27
  * @brief   
  *******************************************************************************
  * @attention
	*	none
  *******************************************************************************
  */ 
//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//
#ifndef VENTI_TWO_H
#define VENTI_TWO_H
//-----------------------------------------------------------------------------//
//- Include Files -------------------------------------------------------------//
//-----------------------------------------------------------------------------//
#include "stm32f4xx_hal.h"
#include "algo.h"
#include "serial_comm_vent.h"
//-----------------------------------------------------------------------------//
//- Peripherals Definition ----------------------------------------------------//
//-----------------------------------------------------------------------------//

//-----------------------------------------------------------------------------//
//- Global Variables Declaration ----------------------------------------------//
//-----------------------------------------------------------------------------//

#define NUM_CHAN_ADC		3

#ifndef SHARE_CST_VENTI_TWO_L
#define SHARE_CST_VENTI_TWO_L
	#ifdef  MAIN_FILE
	
		uint32_t Cnt = 0;
		
		// Data acquisition parameters
		uint8_t 	bSamplingOn = 0;
		uint8_t 	bAutoStart = 0;					// If =1, then sampling starts automatically after initialization (this setting is loaded from config file)
		//////////////////////////////
				
		// ADC
		uint16_t ADCBuf[NUM_CHAN_ADC];		// ADC buffer
		uint16_t Data_ADC[NUM_CHAN_ADC];
		uint8_t ADCConversionsCompleted = 0;	// Counter of ADC conversions during one frame of external clock
		/////////////////////////

		// User button
		uint8_t bUserButtonState = 0;	// 0 - not down, 1 - down
		///////////////

		// PSU
		uint8_t bPOWER_GOOD_STATE = 0;

		#define VDDA_VOLTAGE	3.311
		#define VBAT_DIV		5.3
		#define VBAT_LOW_LIMIT	10.0
		float VBAT = 12.0;	// Battery voltage
		uint16_t skip_VBAT_readings = 50;	// Skip first 50 samples at the beginning to prevent wrong low-battery detection
		//uint8_t bVBAT_LOW_cmd_sent = false;

		// LED
		uint8_t bLEDIndicator = 0;	// 1 - special event indicator
		///////////////
		
		// Sensor thread
		struct ctl_in_pkg ctl_pkg_in;		// package formed to send to CTL thread
		struct ctl_out_pkg ctl_pkg_out;		// last package received from CTL thread
		uint16_t SysEvents = 0;				// Bit field with events for current FRAME period (set by sensor thread. other threads are to send messages to sensor thread to log events)
		//////////////////

		// System configuration
		char str_t[30];	// for parsing needs

		volatile uint16_t LEDCnt = 0;
		volatile uint8_t bFRAMEEvent = 0;
		volatile uint8_t bInitDone = 0;		// Set to 1 after initialization if done (to prevent processing of external interrupt and other events before everything is initialized)
		//////////////////

		// UART communication with host
		uint8_t UARTBufRX[PACKET_SIZE_BYTES];			// UART receive buffer = one PC packet (buffer immediately received from UART peripheral)
		struct serial_packet HostPktRX;			// Last valid packet received from Host (being analyzed by comm thread)
		struct serial_packet HostResponsePkt;	// Packet to form response to Host (then copied to UART FIFO for sending)
		#define FIFO_UART_SIZE 20
		struct serial_packet fifoUART[FIFO_UART_SIZE];	// FIFO of packets to be transmitted to UART

		struct serial_packet spkg;	// packet formed at frame timer event to send to SD thread and UART(if in WIFI mode) (includes selected data from previous FRAME)
		uint16_t spkg_data_buf[PACKET_DATA_LENGTH]; // pressure samples accumulate here before being sent to host
		uint8_t spkg_data_index = 0;
		uint8_t PacketsInUARTFIFO = 0;
		size_t fifo_UART_Head = 0;
		size_t fifo_UART_Tail = 0;
		uint16_t FIFO_UART_overrunerrors = 0;
		uint16_t FIFO_UART_packetssent = 0;
		uint8_t bUART_TX_busy = 1;	// =1 while transmission is in progress
		uint8_t UART_Error = 0;

		uint16_t HostPacketsWithCRCError = 0;					// Increments each time a packet with error CRC is received from PC
		uint16_t HostPacketsWithWrongSignature = 0;		// Increments each time a packet with error signature is received from PC
		uint8_t bHostSendData = 0;							// =1 means that CPU should send data to Host at each SYNC signal via UART
		//////////////////////////

	#else

	#endif
#endif //SHARE_CST_VENTI_TWO_L

//------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------//
#endif /* VENTI_TWO_H */
//------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------//

