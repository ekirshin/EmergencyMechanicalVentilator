/**
  *******************************************************************************
  * @file    ctl_thread.h
  * @author  Evgeny KIRSHIN
  * @version V2.0
  * @date    2020-01-18
  * @brief   
  *******************************************************************************
  * @attention
	*	none
  *******************************************************************************
  */ 
//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//
#ifndef CTL_THREAD_H
#define CTL_THREAD_H
//-----------------------------------------------------------------------------//
//- Include Files -------------------------------------------------------------//
//-----------------------------------------------------------------------------//
#include "stm32f4xx_hal.h"
//-----------------------------------------------------------------------------//
//- Peripherals Definition ----------------------------------------------------//
//-----------------------------------------------------------------------------//

//-----------------------------------------------------------------------------//
//- Global Variables Declaration ----------------------------------------------//
//-----------------------------------------------------------------------------//
#define FIFO_CTL_IN_SIZE 10
#define FIFO_CTL_OUT_SIZE 10
#define CTL_DATA_FIELDS_IN 10
#define CTL_DATA_FIELDS_OUT	8


#ifndef SHARE_CTL_THREAD
#define SHARE_CTL_THREAD

typedef enum {
	MSG_SENSOR_INIT_DAQ,
	MSG_SENSOR_ADC_DATA_READY,
	MSG_SENSOR_FRAME_READY,
	MSG_SENSOR_CTL_DATA_READY,
	MSG_SENSOR_START_DAQ,
	MSG_SENSOR_STOP_DAQ,
}MSG_SensorThreadTypeDef;


typedef enum {
	MSG_CTL_STOP_MOTOR,
	MSG_CTL_DRIVE_MOTOR,
	MSG_CTL_DATA,
	MSG_CTL_SET_MOTOR_SPEED,
	MSG_CTL_SET_RPM,
	MSG_CTL_ACTIVATE_OPERATION,
	MSG_CTL_DEACTIVATE_OPERATION
}MSG_ControlThreadTypeDef;

typedef enum {
	MSG_COMM_INITIALIZE,
	MSG_COMM_PACKET_RECEIVED,
	MSG_COMM_PACKET_READY_TO_SEND,
	MSG_COMM_PACKET_SENT
}MSG_CommThreadTypeDef;

#ifdef  MAIN_FILE

		struct ctl_in_pkg
		{
			uint16_t data[CTL_DATA_FIELDS_IN];	// data packet to CTL thread from Sensor thread
		};
		#define CTL_IN_PKG_SIZE CTL_DATA_FIELDS_IN*2
		
		struct ctl_out_pkg
		{
			uint16_t data[CTL_DATA_FIELDS_OUT];	// data packet from CTL thread to Sensor thread
		};
		#define CTL_OUT_PKG_SIZE CTL_DATA_FIELDS_OUT*2
	
		struct ctl_in_pkg fifoCTL_IN[FIFO_CTL_IN_SIZE];	// FIFO from sensor thread to CTL thread
		size_t fifo_CTL_IN_Head = 0;
		size_t fifo_CTL_IN_Tail = 0;
		uint16_t FIFO_CTL_IN_overrunerrors = 0;
		uint16_t FIFO_CTL_IN_packetssent = 0;
		
		struct ctl_out_pkg fifoCTL_OUT[FIFO_CTL_OUT_SIZE];	// FIFO from CTL thread to sensor thread
		size_t fifo_CTL_OUT_Head = 0;
		size_t fifo_CTL_OUT_Tail = 0;
		uint16_t FIFO_CTL_OUT_overrunerrors = 0;
		uint16_t FIFO_CTL_OUT_packetssent = 0;

		// Battery
		#define VDDA_VOLTAGE	3.32
		#define VBAT_DIV		5.29
		#define VBAT_LOW_LIMIT	11.0

		///// Motor control definitions

		/*
		typedef struct
		{*/
			uint8_t bMotorCtlRelayState = 0;	// 0 - Motor control relay in open position; 1 - in closed position
			uint8_t bIntSwitchState = 0;		// 0 - Motor at the beginning position or slightly after; 1 - motor is in the movement position
			uint8_t bMotorControlSpeedRq = 0;
			uint8_t bMotorControlSpeed = 0;
		//}motor_controller;

		#define PRESSURE_ZERO 230
		#define PRESSURE_INHALE_THRESHOLD 200

		uint16_t iPressure = 0;	// ADC value from pressure sensor
		uint8_t bInhaleDetected = 0;	// set to 1 when pressure dropped below PRESSURE_INHALE_THRESHOLD; reset to 0 when pressure goes above 0
		#define SKIP_PRESSURE_READINGS	100
		uint16_t SkipPressureReadingsCounter;	// Number of pressure readings to skip at the beginning
	/*	float fPressure = 0.0;	// Pressure in PSI
		float P_ADC_to_PSI_bias = 247;
		float P_ADC_to_PSI_k = ;
		*/
		double PressureCycleMin = -1000;
		double PressureCycleMax = 1000;


		// Samping interval, ms
		#define T_S  (10)
		// AC mode control
		bool bACOperationEnabled = false;
		#define MAX_RPM 40
		#define DEFAULT_RPM  12
		uint16_t RPMReq;
		uint16_t RPM = DEFAULT_RPM;	// Minimum respirations per second
		uint32_t RespPeriod = (60*(1000/T_S))/DEFAULT_RPM;

		uint8_t MotorCycleState = 0;	// 0 - motor stopped, 1 - motor started moving, 2 - motor passed switch point

		uint32_t SPSinceCycleStart = 0;	// Counts in T_S time since cycle start (when motor started)

		bool bMotorSlowAlarm = false;	// Alarm set when motor is too slow to operate with requested RPM

	#else
	
		
	#endif
#endif //SHARE_CTL_THREAD

#endif /* CTL_THREAD_H */
//------------------------------------------------------------------------------------//
//------------------------------------------------------------------------------------//
