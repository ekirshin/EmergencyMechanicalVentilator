/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */     
#define MAIN_FILE
#include "board_config.h"
#include "VentiTwoProto.h"
#include "string.h"
#include "tim.h"
#include "adc.h"
#include "usart.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId SensorTaskHandle;
osThreadId ControlTaskHandle;
osThreadId CommTaskHandle;
osThreadId LEDTaskHandle;
osMessageQId SensorTaskMsgQueueHandle;
osMessageQId ControlTaskMsgQueueHandle;
osMessageQId CommTaskMsgQueueHandle;
osSemaphoreId semCTL_INFIFOHandle;
osSemaphoreId semCTL_OUTFIFOHandle;
osSemaphoreId semUARTFIFOHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void PushCTL_INFIFOPkg(struct ctl_in_pkg *pkg);
struct ctl_in_pkg* GetCTL_INFIFOPkg(void);
void PopCTL_INFIFOPkg(void);

void PushCTL_OUTFIFOPkg(struct ctl_out_pkg *pkg);
struct ctl_out_pkg* GetCTL_OUTFIFOPkg(void);
void PopCTL_OUTFIFOPkg(void);

void DriveMotor(void);
void StopMotor(void);
void SetMotorSpeed(uint8_t Speed);

void StartDAQ(void);
void StopDAQ(void);

// Adds package to UART FIFO (if FIFO is not full)
void PushUARTFIFOPkg(struct serial_packet *pkg);
// Returns pointer to package at the head of UART FIFO
struct serial_packet* GetUARTFIFOPkg(void);
// Removes package from UART FIFO
void PopUARTFIFOPkg(void);
void UARTFIFOSendPkg(void);

void PreparePkgPacket(struct serial_packet *pkt);
void ProcessUARTPacket(struct serial_packet *pkt);


/* USER CODE END FunctionPrototypes */

void SensorTaskFunc(void const * argument);
void ControlTaskFunc(void const * argument);
void CommTaskFunc(void const * argument);
void LEDTaskFunc(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];
  
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}                   
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
       
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of semCTL_INFIFO */
  osSemaphoreDef(semCTL_INFIFO);
  semCTL_INFIFOHandle = osSemaphoreCreate(osSemaphore(semCTL_INFIFO), 16);

  /* definition and creation of semCTL_OUTFIFO */
  osSemaphoreDef(semCTL_OUTFIFO);
  semCTL_OUTFIFOHandle = osSemaphoreCreate(osSemaphore(semCTL_OUTFIFO), 16);

  /* definition and creation of semUARTFIFO */
  osSemaphoreDef(semUARTFIFO);
  semUARTFIFOHandle = osSemaphoreCreate(osSemaphore(semUARTFIFO), 40);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of SensorTaskMsgQueue */
  osMessageQDef(SensorTaskMsgQueue, 16, uint16_t);
  SensorTaskMsgQueueHandle = osMessageCreate(osMessageQ(SensorTaskMsgQueue), NULL);

  /* definition and creation of ControlTaskMsgQueue */
  osMessageQDef(ControlTaskMsgQueue, 16, uint16_t);
  ControlTaskMsgQueueHandle = osMessageCreate(osMessageQ(ControlTaskMsgQueue), NULL);

  /* definition and creation of CommTaskMsgQueue */
  osMessageQDef(CommTaskMsgQueue, 100, uint16_t);
  CommTaskMsgQueueHandle = osMessageCreate(osMessageQ(CommTaskMsgQueue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of SensorTask */
  osThreadDef(SensorTask, SensorTaskFunc, osPriorityNormal, 0, 256);
  SensorTaskHandle = osThreadCreate(osThread(SensorTask), NULL);

  /* definition and creation of ControlTask */
  osThreadDef(ControlTask, ControlTaskFunc, osPriorityNormal, 0, 256);
  ControlTaskHandle = osThreadCreate(osThread(ControlTask), NULL);

  /* definition and creation of CommTask */
  osThreadDef(CommTask, CommTaskFunc, osPriorityNormal, 0, 256);
  CommTaskHandle = osThreadCreate(osThread(CommTask), NULL);

  /* definition and creation of LEDTask */
  osThreadDef(LEDTask, LEDTaskFunc, osPriorityBelowNormal, 0, 128);
  LEDTaskHandle = osThreadCreate(osThread(LEDTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_SensorTaskFunc */
/**
  * @brief  Function implementing the SensorTask thread.
  * @param  argument: Not used 
  * @retval None
  */
/* USER CODE END Header_SensorTaskFunc */
void SensorTaskFunc(void const * argument)
{
  /* USER CODE BEGIN SensorTaskFunc */
	osEvent event;
	spkg.cnt = 0;	// first packet
	osDelay(1000);
	StartDAQ();
  /* Infinite loop */
  for(;;)
  {
	  event = osMessageGet(SensorTaskMsgQueueHandle, osWaitForever);

	  if( event.status == osEventMessage )
	  {
		  switch(event.value.v)
		  {
		  case MSG_SENSOR_FRAME_READY:
			  // Collect information from sensors

			  // Pressure sensors
			  ctl_pkg_in.data[1] = Data_ADC[0];
			  ctl_pkg_in.data[2] = Data_ADC[1];

			  // Motor internal switch
			  if(HAL_GPIO_ReadPin(MOT_SW_FB_GPIO_Port, MOT_SW_FB_Pin) == GPIO_PIN_SET)
				  ctl_pkg_in.data[0] = 1;
			  else ctl_pkg_in.data[0] = 0;

			  // User button
			  if(HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin) == GPIO_PIN_RESET)
			  {
				  if(bUserButtonState == 0) osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_DRIVE_MOTOR, osWaitForever);	// Send command to control thread
				  bUserButtonState = 1;
			  }
			  else
			  {
				  //if(bUserButtonState == 1) osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_STOP_MOTOR, osWaitForever);	// Send command to control thread
				  bUserButtonState = 0;
			  }

			  // PSU POWER_GOOD
			  if(HAL_GPIO_ReadPin(PSU_PGOOD_GPIO_Port, PSU_PGOOD_Pin) == GPIO_PIN_SET)
			  {	// High level on POWER_GOOD -> can turn ON supply
				  bPOWER_GOOD_STATE = 1;

			  }
			  else
			  {
				  // Report external power supply is not present -> ALERT?
				  //if(bPOWER_GOOD_STATE == 1) bPOWER_GOOD_STATE = 1;
				  bPOWER_GOOD_STATE = 0;

			  }

			  // Submit to CTL FIFO IN
			  PushCTL_INFIFOPkg(&ctl_pkg_in);
			  if(bHostSendData)
			  {
				  spkg_data_buf[spkg_data_index++] = Data_ADC[0];
				  if(spkg_data_index >= PACKET_DATA_LENGTH)
				  {
					  // Prepare package for UART
					  spkg.cmd = DEV_PACKET_DATA;
					  memcpy(spkg.data, spkg_data_buf, PACKET_DATA_LENGTH*sizeof(uint16_t));
					  spkg_data_index = 0;

					  PreparePkgPacket(&spkg);

					  // Submit package to UART FIFO
					  PushUARTFIFOPkg(&spkg);
				  }
			  }
			  // Battery voltage
			  // Calculate VBAT
			  VBAT = ((float)Data_ADC[2]*VDDA_VOLTAGE*VBAT_DIV)/4095;
			  if((VBAT < VBAT_LOW_LIMIT) && (skip_VBAT_readings == 0))
			  {	// Low battery voltage -> signal ALARM/start battery charging?

			  }
			  if(skip_VBAT_readings) skip_VBAT_readings--;

			  // Start ADC conversion to read sensor
			  // Start ADC DMA
			  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADCBuf, NUM_CHAN_ADC);

			  break;

		  }
	  }
  }
  /* USER CODE END SensorTaskFunc */
}

/* USER CODE BEGIN Header_ControlTaskFunc */
/**
* @brief Function implementing the ControlTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_ControlTaskFunc */
void ControlTaskFunc(void const * argument)
{
  /* USER CODE BEGIN ControlTaskFunc */
	osEvent event;
	struct ctl_in_pkg *data_pkg_in;
	struct ctl_out_pkg data_pkg_out;
  bMotorCtlRelayState = 0;		 // Relay is not activated at init
  uint16_t MotorSwitchOnCnt = 0;	// Time counter in ms since internal switch of the motor becomes active
  SkipPressureReadingsCounter = SKIP_PRESSURE_READINGS;

  osDelay(500);
  HAL_GPIO_WritePin(RL1_CTL_GPIO_Port, RL1_CTL_Pin, GPIO_PIN_RESET);	// Enable system power (VBAT)
  osDelay(500);
  HAL_GPIO_WritePin(PSU_PON_GPIO_Port, PSU_PON_Pin, GPIO_PIN_RESET);	// Deactivate relay

  /* Infinite loop */
  for(;;)
  {
	  // DEBUG
/*	  osDelay(500);
	  HAL_GPIO_WritePin(RL2_CTL_GPIO_Port, RL2_CTL_Pin, GPIO_PIN_SET);	// Deactivate relay
	  osDelay(500);
	  HAL_GPIO_WritePin(RL2_CTL_GPIO_Port, RL2_CTL_Pin, GPIO_PIN_RESET);	// Deactivate relay
*/
	  //~DEBUG
	  // Check incoming action messages
	  event = osMessageGet(ControlTaskMsgQueueHandle, osWaitForever);
	  if( event.status == osEventMessage )
	  {
		  switch(event.value.v)
		  {
		  	  case MSG_CTL_STOP_MOTOR:
		  		  StopMotor();
		  		  break;

			  case MSG_CTL_DRIVE_MOTOR:
				  DriveMotor();
				  break;

			  case MSG_CTL_SET_MOTOR_SPEED:
				  bMotorControlSpeed = bMotorControlSpeedRq;
				  SetMotorSpeed(bMotorControlSpeed);
				  break;

			  case MSG_CTL_SET_RPM:
				  if((RPMReq > 0) && (RPMReq < MAX_RPM))
				  {
					  RPM = RPMReq;
					  RespPeriod = (60*(1000/T_S))/RPM;
				  }
				  SetMotorSpeed(bMotorControlSpeed);
				  break;

			  case MSG_CTL_ACTIVATE_OPERATION:
				  bACOperationEnabled = true;
				  HAL_GPIO_WritePin(RL1_CTL_GPIO_Port, RL1_CTL_Pin, GPIO_PIN_RESET);	// Enable system power (VBAT)
				  break;

			  case MSG_CTL_DEACTIVATE_OPERATION:
			  	  bACOperationEnabled = false;
			  	  StopMotor();
			  	  break;

			  case MSG_CTL_DATA:
				// Read sensor input package from FIFO
				data_pkg_in = GetCTL_INFIFOPkg();

				bIntSwitchState = data_pkg_in->data[0];
				iPressure = data_pkg_in->data[1];

				// Remove package from FIFO
				PopCTL_INFIFOPkg();

				if(bACOperationEnabled)
				{	// AC mode operation enabled -> motor is controlled based on parameters and pressure
					SPSinceCycleStart++;	// Continue cycle
					if(SkipPressureReadingsCounter) SkipPressureReadingsCounter--;
					else
					{
						if(MotorCycleState == 0)
						{	// Motor parked -> wait for either patient inhale or timing to start next cycle
							if((iPressure < PRESSURE_INHALE_THRESHOLD) || (SPSinceCycleStart > RespPeriod))
							{
								if(bInhaleDetected == 0)
								{	// Inhale detected - start respiration cycle
									bInhaleDetected = 1;
									SPSinceCycleStart = 0;
									PressureCycleMin = -1000;
									PressureCycleMax = 1000;
									bMotorSlowAlarm = false;
									MotorCycleState = 1;
									DriveMotor();
								}
							}
						}
						else if(MotorCycleState == 1)
						{	// Motor triggered
							if(SPSinceCycleStart > 30)
							{	// Motor not moving -> ALARM

							}
							if(bIntSwitchState == 1)
								MotorCycleState = 2;	// Motor passed switch point

						}
						else if(MotorCycleState == 2)
						{	// Motor passed switch point - wait for it to reach switch state 0 before cycle expires or report alarm
							{	// Switch off motor drive relay (the rest of cycle motor will do itself)
								HAL_GPIO_WritePin(RL2_CTL_GPIO_Port, RL2_CTL_Pin, GPIO_PIN_SET);	// Deactivate relay
								bMotorCtlRelayState = 0;	// stop driving motor
							}
							if(bIntSwitchState == 0) MotorCycleState = 0;	// End of cycle
							else if(SPSinceCycleStart > RespPeriod) bMotorSlowAlarm = true;
						}
						// Analyze pressure throughout the whole cycle
						if(iPressure > (PRESSURE_ZERO-5)) bInhaleDetected = 0;	// Reset inhale detected flag
						if(iPressure < PressureCycleMin) PressureCycleMin = iPressure;
						if(iPressure > PressureCycleMax) PressureCycleMax = iPressure;
					}
				}
				else
				{	// Standby mode (testing/calibration)
					if(bIntSwitchState) MotorSwitchOnCnt++;
					else MotorSwitchOnCnt = 0;
					if(MotorSwitchOnCnt > 15)
					{
						HAL_GPIO_WritePin(RL2_CTL_GPIO_Port, RL2_CTL_Pin, GPIO_PIN_SET);	// Deactivate relay
						bMotorCtlRelayState = 0;	// stop driving motor
					}
					if(SkipPressureReadingsCounter) SkipPressureReadingsCounter--;
					else
					{
						// Analyze pressure
						if(iPressure < PRESSURE_INHALE_THRESHOLD)
						{
							if(bInhaleDetected == 0)
							{	// Inhale detected - start pumping air
								DriveMotor();
								bInhaleDetected = 1;
							}
						}
						else if(iPressure > (PRESSURE_ZERO-5)) bInhaleDetected = 0;
					}
				}


				break;
		  }
	  }
  }
  /* USER CODE END ControlTaskFunc */
}

/* USER CODE BEGIN Header_CommTaskFunc */
/**
* @brief Function implementing the CommTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_CommTaskFunc */
void CommTaskFunc(void const * argument)
{
  /* USER CODE BEGIN CommTaskFunc */
	osEvent event;
	uint8_t temp;
	temp = huart2.Instance->DR;
	HAL_UART_Receive_DMA(&huart2, UARTBufRX, PACKET_SIZE_BYTES);
	bUART_TX_busy = 0;	// Enable UART transmission
  /* Infinite loop */
  for(;;)
  {
	  event = osMessageGet(CommTaskMsgQueueHandle, osWaitForever);

	  		if(event.status == osEventMessage)
	  		{
	  			switch(event.value.v)
	  			{
	  			case MSG_COMM_INITIALIZE:
	  				// Clear garbage from UART RX register (if any)
	  				temp = huart2.Instance->DR;
	  				// Start UART communication with host
	  				HAL_UART_Receive_DMA(&huart2, UARTBufRX, PACKET_SIZE_BYTES);
	  				// Request to sensor thread to initialize DAQ system
	  				//osMessagePut(SensorTaskMsgQueueHandle, MSG_SENSOR_INIT_DAQ, osWaitForever);
	  				bUART_TX_busy = 0;	// Enable UART transmission
	  				break;
	  			case MSG_COMM_PACKET_RECEIVED:
	  				ProcessUARTPacket(&HostPktRX);
	  				break;
	  			case MSG_COMM_PACKET_READY_TO_SEND:
	  				// Check if UART is still sending
	  				if(!bUART_TX_busy) UARTFIFOSendPkg();
	  				break;
	  			case MSG_COMM_PACKET_SENT:
	  				// Packet was sent to UART - send next one in FIFO
	  				PopUARTFIFOPkg();
	  				if(PacketsInUARTFIFO) UARTFIFOSendPkg();
	  				break;
	  			}
	  		}
  }
  /* USER CODE END CommTaskFunc */
}

/* USER CODE BEGIN Header_LEDTaskFunc */
/**
* @brief Function implementing the LEDTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LEDTaskFunc */
void LEDTaskFunc(void const * argument)
{
  /* USER CODE BEGIN LEDTaskFunc */
	/* Infinite loop */
  for(;;)
  {
	  LedGreen_Toggle();
	  osDelay(300);
  }
  /* USER CODE END LEDTaskFunc */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
// Initializes components related to DAQ system
// Launches data acquisition, if configured
void StartDAQ(void)
{	// Essentially - just start FRAME timer (all sampling initiation is started by timer interrupt handler)
	// Initialize and start master frame rate timer 6
	//MX_TIM6_Init();
	HAL_TIM_Base_Start_IT(&htim4);

	bSamplingOn = 1;	// indicator that sampling is running
}

void StopDAQ(void)
{
	bSamplingOn = 0;	// indicator that sampling is not running

	// Stop timers
	HAL_TIM_Base_Stop_IT(&htim4);
}

void DriveMotor(void)
{
	// Check if motor is already being driven
	if(bIntSwitchState == 0)
	{	// Motor is in parked position
		HAL_GPIO_WritePin(RL2_CTL_GPIO_Port, RL2_CTL_Pin, GPIO_PIN_RESET);	// Activate relay
		bMotorCtlRelayState = 1;	// driving motor
	}
}

void StopMotor(void)
{
	HAL_GPIO_WritePin(RL1_CTL_GPIO_Port, RL1_CTL_Pin, GPIO_PIN_SET);	// Deactivate POWER control relay
}

void SetMotorSpeed(uint8_t Speed)
{
	if(Speed == 1)
		HAL_GPIO_WritePin(RL3_CTL_GPIO_Port, RL3_CTL_Pin, GPIO_PIN_RESET);	// Activate relay => HIGH speed
	else HAL_GPIO_WritePin(RL3_CTL_GPIO_Port, RL3_CTL_Pin, GPIO_PIN_SET);	// DeActivate relay => LOW speed
}

// Adds package to CTL_IN FIFO (if FIFO is not full)
void PushCTL_INFIFOPkg(struct ctl_in_pkg *pkg)
{
	if(osSemaphoreWait(semCTL_INFIFOHandle, 0) == osOK)
	{
		memcpy(&fifoCTL_IN[fifo_CTL_IN_Head], pkg, CTL_IN_PKG_SIZE);
		// Advance the FIFO index to the next free record
		fifo_CTL_IN_Head = fifo_CTL_IN_Head < (FIFO_CTL_IN_SIZE - 1) ? fifo_CTL_IN_Head + 1 : 0;
		// Signal to ControlTaskMsg that new Data Record is waiting in the FIFO
		osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_DATA, osWaitForever);
		FIFO_CTL_IN_packetssent++;
	}
	else
	{
		// FIFO is full - indicates a missed Data Sample Record(s)
		FIFO_CTL_IN_overrunerrors++;
	}
}

// Returns pointer to package at the head of CTL IN FIFO
struct ctl_in_pkg* GetCTL_INFIFOPkg(void)
{
	return &fifoCTL_IN[fifo_CTL_IN_Tail];
}

// Removes package from CTL IN FIFO
void PopCTL_INFIFOPkg(void)
{
	// Advance the FIFO index
	fifo_CTL_IN_Tail = fifo_CTL_IN_Tail < (FIFO_CTL_IN_SIZE - 1) ? fifo_CTL_IN_Tail + 1 : 0;
	// Decrease semaphore count
	osSemaphoreRelease(semCTL_INFIFOHandle);
}

// Adds package to CTL_OUT FIFO (if FIFO is not full)
void PushCTL_OUTFIFOPkg(struct ctl_out_pkg *pkg)
{
	if(osSemaphoreWait(semCTL_OUTFIFOHandle, 0) == osOK)
	{
		memcpy(&fifoCTL_OUT[fifo_CTL_OUT_Head], pkg, CTL_OUT_PKG_SIZE);
		// Advance the FIFO index to the next free record
		fifo_CTL_OUT_Head = fifo_CTL_OUT_Head < (FIFO_CTL_OUT_SIZE - 1) ? fifo_CTL_OUT_Head + 1 : 0;
		// Signal to SensorTaskMsg that new Data Record is waiting in the FIFO
		osMessagePut(SensorTaskMsgQueueHandle, MSG_SENSOR_CTL_DATA_READY, osWaitForever);
		FIFO_CTL_OUT_packetssent++;
	}
	else
	{
		// FIFO is full - indicates a missed Data Sample Record(s)
		FIFO_CTL_OUT_overrunerrors++;
	}
}

// Returns pointer to package at the head of CTL OUT FIFO
struct ctl_out_pkg* GetCTL_OUTFIFOPkg(void)
{
	return &fifoCTL_OUT[fifo_CTL_OUT_Tail];
}

// Removes package from CTL OUT FIFO
void PopCTL_OUTFIFOPkg(void)
{
	// Advance the FIFO index
	fifo_CTL_OUT_Tail = fifo_CTL_OUT_Tail < (FIFO_CTL_OUT_SIZE - 1) ? fifo_CTL_OUT_Tail + 1 : 0;
	// Decrease semaphore count
	osSemaphoreRelease(semCTL_OUTFIFOHandle);
}

// Adds package to UART FIFO (if FIFO is not full)
void PushUARTFIFOPkg(struct serial_packet *pkg)
{
	if(osSemaphoreWait(semUARTFIFOHandle, 0) == osOK)
	{
		memcpy(&fifoUART[fifo_UART_Head], pkg, PACKET_SIZE_BYTES);
		// Advance the FIFO index to the next free record
		fifo_UART_Head = fifo_UART_Head < (FIFO_UART_SIZE - 1) ? fifo_UART_Head + 1 : 0;
		PacketsInUARTFIFO++;
		// Signal to CommTaskMsg the new Data Record is waiting in the FIFO
		osMessagePut(CommTaskMsgQueueHandle, MSG_COMM_PACKET_READY_TO_SEND, osWaitForever);
		FIFO_UART_packetssent++;
	}
	else
	{
		// FIFO is full - indicates a missed Data Sample Record(s)
		FIFO_UART_overrunerrors++;
	}
}

// Returns pointer to package at the head of UART FIFO
struct serial_packet* GetUARTFIFOPkg(void)
{
	return &fifoUART[fifo_UART_Tail];
}

// Removes package from UART FIFO
void PopUARTFIFOPkg(void)
{
	// Advance the FIFO index
	fifo_UART_Tail = fifo_UART_Tail < (FIFO_UART_SIZE - 1) ? fifo_UART_Tail + 1 : 0;
	PacketsInUARTFIFO--;
	// Decrease semaphore count
	osSemaphoreRelease(semUARTFIFOHandle);
}

void UARTFIFOSendPkg(void)
{	// Picks first packet from FIFO and sends it to UART
	UART_Error = HAL_UART_Transmit_DMA(&huart2, (uint8_t *)GetUARTFIFOPkg(), PACKET_SIZE_BYTES);
	bUART_TX_busy = 1;
}

void ProcessUARTPacket(struct serial_packet *pkt)
{
	// First validate packet
	if(pkt->sig_start == SIG_START)
	{	// compute CRC
		if(CalcPacketCRC(pkt) == pkt->crc)
		{ // Packet with valid CRC received - process packet

			if(pkt->cmd == PC_CMD_GET_DATA)
			{	// Start sending data to host
				bHostSendData = 1;	// indicator to send data to host
			}
			else if(pkt->cmd == PC_CMD_STOP_DATA)
			{	// Stop sending data to host
				bHostSendData = 0;	// indicator not to send data to host
			}
			else if(pkt->cmd == PC_CMD_STOP_MOTOR)
			{	// Stop Disable 12V power to the system => emergency shutdown
				osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_STOP_MOTOR, osWaitForever);	// Send command to control thread
			}
			else if(pkt->cmd == PC_CMD_SET_MOTOR_SPEED)
			{	// Select motor LOW/HIGH speed
				bMotorControlSpeedRq = pkt->data[0];
				osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_SET_MOTOR_SPEED, osWaitForever);	// Send command to control thread
			}
			else if(pkt->cmd == PC_CMD_SET_RPM)
			{	// Set RPM
				if((pkt->data[0] > 0) && (pkt->data[0] < 40))
				{
					RPMReq = pkt->data[0];
					osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_SET_RPM, osWaitForever);	// Send command to control thread
				}
			}
			else if(pkt->cmd == PC_CMD_OPERATION_ENABLE)
			{	// Enable AC operation
				osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_ACTIVATE_OPERATION, osWaitForever);	// Send command to control thread
			}
			else if(pkt->cmd == PC_CMD_OPERATION_DISABLE)
			{	// Disable AC operation
				osMessagePut(ControlTaskMsgQueueHandle, MSG_CTL_DEACTIVATE_OPERATION, osWaitForever);	// Send command to control thread
			}

		}
		else HostPacketsWithCRCError++;
	}
	else HostPacketsWithWrongSignature++;
}

// Fills packet with appropriate fields and data to be sent to Host, calculates CRC
void PreparePkgPacket(struct serial_packet *pkt)
{
	pkt->sig_start = SIG_START;
	pkt->cnt++;
	pkt->crc = CalcPacketCRC(pkt);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{	// Packet received over UART
	if(huart == &huart2)
	{	// Data from host
		// Copy received block to process in main thread
		memcpy((uint8_t *)&HostPktRX, UARTBufRX, PACKET_SIZE_BYTES);
		// Restart UART RX DMA
		HAL_UART_Receive_DMA(&huart2, UARTBufRX, PACKET_SIZE_BYTES);
		// Send message to communication thread that packet is ready for processing
		osMessagePut(CommTaskMsgQueueHandle, MSG_COMM_PACKET_RECEIVED, osWaitForever);
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{	// Packet transmitted over UART - safe to start next UART transmission
	if(huart == &huart2)
	{
		bUART_TX_busy = 0;
		osMessagePut(CommTaskMsgQueueHandle, MSG_COMM_PACKET_SENT, osWaitForever);
	}
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	int i,j;
	uint32_t ADCSampleAvg;
	hadc1.State = HAL_ADC_STATE_READY;
	hadc1.Instance->CR2 &= ~ADC_CR2_DMA;

	// Copy data from ADC buffer
	memcpy(Data_ADC, ADCBuf, NUM_CHAN_ADC*2);	// 2 bytes per channel, 2 channels
	ADCConversionsCompleted++;

	// Let sensor thread know that ADC data is ready
	//osMessagePut(SensorTaskMsgQueueHandle, MSG_SENSOR_ADC_DATA_READY, osWaitForever);
}

/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
