#include "serial_comm_vent.h"

uint8_t CalcPacketCRC(struct serial_packet *sp)
{
	uint8_t crc = 0;
	uint8_t *buf = (uint8_t *)sp;
	
	for(int i = 2; i < PACKET_SIZE_BYTES-2; i++)
		crc += buf[i];
	return crc;
	// sp->crc = crc;
}
