#ifndef SERIAL_COMM_VENT_H
#define SERIAL_COMM_VENT_H

#include "stdint.h"

#define SIG_START_L	0xA5
#define SIG_START_H	0xF0
#define SIG_START	0xF0A5

#define PACKET_DATA_LENGTH	20
struct serial_packet
{
	uint16_t	sig_start;	// Start packet signature
	uint16_t	cnt;			// Counter increasing with each new packet
	uint16_t 	cmd;		// Command field for downward packets, Status field for upward packets with ID=STATUS, Valid field for packets with ID=DATA
	uint16_t 	data[PACKET_DATA_LENGTH];	// sensor data, 2 bytes per packet
	uint16_t	crc;			// checksum, calculated as a sum of all bytes starting from id until end of data
};

#define PACKET_SIZE_BYTES	sizeof(struct serial_packet)
	
uint8_t CalcPacketCRC(struct serial_packet *sp);

// Commands from host to device
#define PC_CMD_GET_DATA 				1	// Start sending data from CPU to PC (format in data fields)
#define PC_CMD_STOP_DATA 				2	// Stop sending data from CPU to PC
#define PC_CMD_SET_V_MODE 				3	// Set ventilator mode
#define PC_CMD_SET_RPM 					4	// Set minimum respirations per minute
#define PC_CMD_SET_MOTOR_SPEED 			5	// Select motor speed (LOW/HIGH)
#define PC_CMD_STOP_MOTOR 				6	// Stop motor (switches OFF 12V supply)
#define PC_CMD_OPERATION_ENABLE 		7	// Enable AC operation
#define PC_CMD_OPERATION_DISABLE 		8	// Disable AC operation


// Packet types from device to host
#define DEV_PACKET_DATA	100

#endif // SERIAL_COMM_VENT_H
