﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO.Ports;
using System.IO;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;

namespace DataAcquisition
{
    public partial class MainForm : Form
    {
        ///////// Packet reception and exchange 
        Queue<serial_packet> CommQueue = new Queue<serial_packet>(); // Queue of commands that background thread is to execute. When it's empty background thread just monitors oven temperature
        object _lock = new object();                // Object to lock CommQueue for thread-safe operation 
        uint PacketsReceived = 0;
        DataPkg pkg_tst = new DataPkg();

        ///////// COM port communication
        string COMName;     // COM port name

        ///////// General operation
        bool isRunning = false;

        /////////// Graphs
        double GraphSample;   // Incoming samples for each waveform
        double LastMeanValue = 0.0; // Mean value of received packet

        double[] GraphBuffer = new double[Constants.GRAPH_UPDATE_PERIOD_SAMPLES];

        double Scaletime = 0;      // Current time on scale (increments as samples are coming)

        double Ts = 10.0e-3;     // Current sampling rate (default 1kHz)

        bool bAllowPaint = true;         // switch - set to 0 when updating graphs

        ///////////// Save data to file
        bool SaveToFile;
        string SaveFolder;
        int FilePacketsPending; // Number of packets collected for further saving to file
        MemoryStream ms;
        FileStream fs;
        BinaryWriter writer;

        // Pressure processing
        double ZeroPressure_ADC = 2440;
        double VDDA = 3.31; //V
        double V_ADC;   // Voltage at ADC input
        double V_ref = 1.648;   // Voltage reference, V
        double INA_Gain = 50.4; // AD8221
        //double INA_Gain = 19.3; // AD8221
        double V_diff;  // Voltage difference at sensor

        double Pressure_kPa;
        double Pressure_PSI;
        double Pressure_cmH2O;

        double PS_offset_mv = 0.02;
        double PS_sensitivity = 1.2e-3; // V/kPa
        


        public class Constants
        {
            public const uint DATA_LENGTH = 20;
            public const uint PACKET_SIZE = 2 + 2 + 2 + DATA_LENGTH * 2 + 2;
            public const byte SIG_START_L = 0xA5;
            public const byte SIG_START_H = 0xF0;
            public const ushort SIG_START = 0xF0A5;

            // Commands to device
            public const byte PC_CMD_GET_DATA = 1;          // Starts data transmission from device to PC
            public const byte PC_CMD_STOP_DATA = 2;         // Stops data transmission from device to PC
            public const byte PC_CMD_SET_V_MODE = 3;        // Set ventilator mode
            public const byte PC_CMD_SET_RPM = 4;        // Set timing (respirations per minute)
            public const byte PC_CMD_SET_MOTOR_SPEED = 5;        // Select high-speed or low-speed mode
            public const byte PC_CMD_STOP_MOTOR = 6;        // Select high-speed or low-speed mode
            public const byte PC_CMD_OPERATION_ENABLE = 7;        // Enable AC operation
            public const byte PC_CMD_OPERATION_DISABLE = 8;        // Disable AC operation

            // Commands/indicators from device
            public const byte DEV_PACKET_DATA = 100;          // Indicates packet holds data from device

            //           public const double Ts = 10e-3;              // sampling period for signals

            public const int GRAPH_UPDATE_PERIOD_SAMPLES = 20;  // Update graphs every 20 samples
            public const int GRAPH_DISPLAY_SAMPLES = 1000;      // Maximum number of samples to keep on graph (per series)

            public const double GRAPH_VISIBLE_TIME = 10.0;       // seconds of data to keep on graphs

        }

        public class serial_packet
        {
            public ushort sig_start;    // Start packet signature
            public ushort cnt;            // Counter increasing with each new packet
            public ushort cmd;            // Command to device
            public ushort[] data;       // sensor data, 2 bytes per packet
            public ushort crc;            // checksum, calculated as a sum of all bytes starting from id until end of data

            public serial_packet()
            {
                data = new ushort[Constants.DATA_LENGTH];
            }

            public serial_packet(byte[] PkgBuf)
            {   // Constructs packet from byte array, assuming the byte array is containing a packet
                sig_start = (ushort)(PkgBuf[1] * 256 + PkgBuf[0]);
                cnt = (ushort)(PkgBuf[3] * 256 + PkgBuf[2]);
                cmd = (ushort)(PkgBuf[5] * 256 + PkgBuf[4]);
                data = new ushort[Constants.DATA_LENGTH];
                for (int i = 0; i < Constants.DATA_LENGTH; i++)
                    data[i] = (ushort)(PkgBuf[i * 2 + 6 + 1] * 256 + PkgBuf[i * 2 + 6]);
                crc = (ushort)(PkgBuf[6 + Constants.DATA_LENGTH * 2 + 1] * 256 + PkgBuf[6 + Constants.DATA_LENGTH * 2]);
            }

            public byte[] ToByteArray()
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    ms.Write(BitConverter.GetBytes(sig_start), 0, 2);
                    ms.Write(BitConverter.GetBytes(cnt), 0, 2);
                    ms.Write(BitConverter.GetBytes(cmd), 0, 2);
                    foreach (ushort value in data)
                        ms.Write(BitConverter.GetBytes(value), 0, 2);
                    ms.Write(BitConverter.GetBytes(crc), 0, 2);
                    return ms.ToArray();
                }

            }

            public byte CalcPacketCRC()
            {
                byte crc = 0;
                byte[] arr = ToByteArray();

                for (int i = 2; i < Constants.PACKET_SIZE - 2; i++)
                    crc += arr[i];
                return crc;
            }
        };
        /*
        public class SamplesPkg
        {
            public uint NumSamples;
            public double[] Samples;

            public SamplesPkg()
            {

            }
            public SamplesPkg(byte[] SamplesBuf)
            {
                Samples = new double[SamplesBuf.Length];

                for (int i = 0; i < SamplesBuf.Length; i++)
                    Samples[i] = SamplesBuf[i];
            }

        }
        */
        public class DataPkg
        {
            public serial_packet spacket;
            public uint PkgNum;
            public bool LastPkg = false;

            public DataPkg()
            {

            }
            public DataPkg(byte[] PkgBuf)
            {
                spacket = new serial_packet(PkgBuf);
            }
            public DataPkg(serial_packet sp)
            {
                spacket = sp;
            }

        }

        private bool ValidatePacket(ref serial_packet sp)
        {
            // Check start signature
            if (sp.sig_start != Constants.SIG_START) return false;
            //if (sp.CalcPacketCRC() != sp.crc) return false;
            return true;
        }
        

        public MainForm()
        {
            InitializeComponent();
        }

        private void SetInterfaceDisconnected()
        {
            bnStart.Tag = "0";
            bnStart.Text = "Start";
            bnConnectCOM.Text = "CONNECT";
            bnConnectCOM.Tag = "0";

        }

        private void SetInterfaceConnected()
        {
            bnConnectCOM.Tag = "1";
            bnConnectCOM.Text = "DISCONNECT";
        }

        private void bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //if ((string)bnDAQStart.Tag != "1") return;

            if (e.ProgressPercentage == 01)
            {   // Error occured
                Exception ex = (Exception)e.UserState;
                SetInterfaceDisconnected();
                tbLog.AppendText(ex.Message + "\r\n");
                tbLog.AppendText("Error in communication\r\n");
                return;
            }
            else if (e.ProgressPercentage == 1)
            {   // Error occured
                Exception ex = (Exception)e.UserState;
                SetInterfaceDisconnected();
                tbLog.AppendText(ex.Message + "\r\n");
                tbLog.AppendText("Device disconnected\r\n");
                return;
            }
            else if (e.ProgressPercentage == 2)
            {   // Port opened
                SetInterfaceConnected();
                tbLog.AppendText("Device connected\r\n");

                // If successful -> Start receiving pressure from device
                // Generate packet with "Start/Stop DAQ command", add it to the command queue
                serial_packet sp_tx = new serial_packet();
                sp_tx.cmd = Constants.PC_CMD_GET_DATA;

                lock (_lock)
                {
                    CommQueue.Enqueue(sp_tx);
                }

                return;
            }
            else if (e.ProgressPercentage == 100)
            {   // Last packet received (thread stopped)
                isRunning = false;
                tbLog.AppendText("CPU packet reception stopped\r\n");
                return;
            }
            else
            {
                DataPkg pkg = (DataPkg)e.UserState;

                if (pkg.spacket.cmd == Constants.DEV_PACKET_DATA)
                    ProcessSamples(pkg);

                PacketsReceived++;
                tbPacketsRcvd.Text = PacketsReceived.ToString();
            }

            

        }

        private void ProcessSamples(DataPkg pkg)
        {
            Scaletime = Scaletime + Ts;     // incrementing scale time with each sample
            //////////// Update graphs ///////////////////////////////////////////

            if (pkg.spacket.cmd == Constants.DEV_PACKET_DATA)
            {
                bAllowPaint = false;
                // Add samples to graph, compute mean value
                LastMeanValue = 0;
                for (int j = 0; j < Constants.DATA_LENGTH; j++)
                {
                    LastMeanValue += pkg.spacket.data[j];

                    // Calculate pressure
                    //double ZeroPressure_ADC = 2440;
                    /*
                                        //V_ADC = VDDA/4095*pkg.spacket.data[j];   // Voltage at ADC input
                                        //V_diff = (V_ADC - V_ref)/ INA_Gain;  // Voltage difference at sensor
                                        V_ADC = VDDA / 4095 * (pkg.spacket.data[j] - ZeroPressure_ADC);   // Voltage at ADC input
                                        V_diff = (V_ADC) / INA_Gain;  // Voltage difference at sensor

                                        //Pressure_kPa = (V_diff - PS_offset_mv) / PS_sensitivity;
                                        Pressure_kPa = (V_diff)/ PS_sensitivity ;
                                        Pressure_PSI = Pressure_kPa * 0.145038;
                                        Pressure_cmH2O = Pressure_PSI / 0.01422;

                                        // Add to graph
                                        chGraph1.Series[0].Points.AddY(Pressure_cmH2O);
                                        */
                    // Apply calibration to samples
                    Pressure_cmH2O = (pkg.spacket.data[j] - 220) / 10 + 5.2;
                    chGraph1.Series[0].Points.AddY(Pressure_cmH2O);
                }
                if (chGraph1.Series[0].Points.Count > Constants.GRAPH_DISPLAY_SAMPLES)
                    for (int j = 0; j < (chGraph1.Series[0].Points.Count - Constants.GRAPH_DISPLAY_SAMPLES); j++)
                        chGraph1.Series[0].Points.RemoveAt(0);

                bAllowPaint = true;
                LastMeanValue /= Constants.DATA_LENGTH;
            }
        }

        private void bnDAQStart_Click(object sender, EventArgs e)
        {
            // Generate packet with "Start command", add it to the command queue
            serial_packet sp_tx = new serial_packet();
            if ((string)bnStart.Tag == "0")
            {
                sp_tx.cmd = Constants.PC_CMD_GET_DATA;
/*
                SaveToFile = cbSaveDataToFile.Checked;

                //for(int i = 0; i < Constants.WAVEFORMS_PER_GRAPH; i++)
                GraphChannel[0] = (int)nudGraph1Sig1.Value - 1;
                GraphChannel[1] = (int)nudGraph1Sig2.Value - 1;
                GraphChannel[2] = (int)nudGraph1Sig3.Value - 1;
                GraphChannel[3] = (int)nudGraph1Sig4.Value - 1;

                GraphEn[0] = cbGraph1Sig1En.Checked;
                GraphEn[1] = cbGraph1Sig2En.Checked;
                GraphEn[2] = cbGraph1Sig3En.Checked;
                GraphEn[3] = cbGraph1Sig4En.Checked;

                if (SaveToFile)
                {
                    SaveFolder = tbDataPath.Text;
                    DateTime localDate = DateTime.Now;
                    SaveFolder += "/" + localDate.ToString("yyyy_MM_dd_HH_mm_ss");
                    FilePacketsPending = 0;

                    // Create directory inside selected folder
                    try
                    {
                        if (!System.IO.File.Exists(SaveFolder))
                        {
                            System.IO.Directory.CreateDirectory(SaveFolder);
                        }
                    }
                    catch (Exception ex)
                    {
                        tbLog.AppendText("Could not create folder (" + ex.ToString() + "). Process stopped.\r\n");
                        return;
                    }

                    // Open file for binary data writing
                    fs = File.Open(SaveFolder + "/data.bin", FileMode.Append);
                    writer = new BinaryWriter(fs);
                }
                */
                isRunning = true;

                bnStart.Tag = "1";
                bnStart.Text = "Stop";

            }
            else
            {
                sp_tx.cmd = Constants.PC_CMD_STOP_DATA;
                bnStart.Tag = "0";
                bnStart.Text = "Start";
            }
            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }

        private void bnSetGraphScales_Click(object sender, EventArgs e)
        {
            chGraph1.ChartAreas[0].AxisY.Minimum = (double)nudGraph1Min.Value;
            chGraph1.ChartAreas[0].AxisY.Maximum = (double)nudGraph1Max.Value;
        }

        private void bnSetAdaptiveYScale_Click(object sender, EventArgs e)
        {
            double GraphMin;
            double GraphMax;


            GraphMin = chGraph1.Series[0].Points.FindMinByValue().YValues[0];
            GraphMax = chGraph1.Series[0].Points.FindMaxByValue().YValues[0];


            if (GraphMin == GraphMax)
            {
                GraphMin -= 100;
                GraphMax += 100;
            }
            
            chGraph1.ChartAreas[0].AxisY.Minimum = GraphMin - (GraphMax - GraphMin) * 0.1;
            chGraph1.ChartAreas[0].AxisY.Maximum = GraphMax + (GraphMax - GraphMin) * 0.1;
        }


        private void bnConnectCOM_Click(object sender, EventArgs e)
        {
            COMName = tbCOMPort.Text;
            if ((string)bnConnectCOM.Tag == "0")
            {
                // Start the background worker
                bwCOM.RunWorkerAsync();
            }
            else
            {
                bnConnectCOM.Tag = "0";
                bnConnectCOM.Text = "Connect";
                bwCOM.CancelAsync();
            }
        }

        private void bwCOM_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            SerialPort SPort;
            //int BytesInBuf = 0;
            uint PkgNum = 0;
            byte PktNum = 0;        // Packet number for sent packets
            uint i;
            int j = 0;
            byte[] PacketBufRX = new byte[Constants.PACKET_SIZE];
            byte[] PacketBufTX = new byte[Constants.PACKET_SIZE];
            uint PacketBufValidBytesRX = 0;    // Number of bytes in PacketBufRX related to the beginning of the next incoming packet
            // array < unsigned char >^ SPBuf = gcnew array < unsigned char > (2 ^ 20);    // Buffer read from serial port (must be empty before reading data from port)
            byte[] SPBuf = new byte[Constants.PACKET_SIZE];
            bool synced = false;    // indicates if beginning of a packet is identifed and the logic is receiving packets assuming they follow one by one (checking their validity)
            DataPkg pkg;
            serial_packet sp;

            SPort = new SerialPort();

            // Allow the user to set the appropriate properties.
            SPort.PortName = COMName;
            SPort.BaudRate = 115200;
            SPort.Parity = (Parity)Enum.Parse(typeof(Parity), "None", true);
            SPort.DataBits = 8;
            SPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), "One");
            SPort.Handshake = (Handshake)Enum.Parse(typeof(Handshake), "None");
            SPort.ReadBufferSize = 2 ^ 20;
            SPort.WriteBufferSize = 2 ^ 20;

            // Set the read/write timeouts
            SPort.ReadTimeout = 500;
            SPort.WriteTimeout = 500;

            try
            {
                SPort.Open();
            }
            catch (InvalidOperationException ex)
            {
                worker.ReportProgress(1, ex);
                Thread.Sleep(200);
                e.Cancel = true;
                return;
            }
            catch (IOException ex)
            {
                worker.ReportProgress(1, ex);
                Thread.Sleep(200);
                e.Cancel = true;
                return;
            }

            worker.ReportProgress(2, 0);

            try
            {

                while (true)
                {
                    // Test serial port buffer
                    if (SPort.BytesToRead >= Constants.PACKET_SIZE)
                    {
                        if (synced)
                        {
                            SPort.Read(SPBuf, 0, (int)Constants.PACKET_SIZE);    // read exactly one packet from serial port
                                                                                 // Copy packet into the packet buffer
                                                                                 //for (i = 0; i < Constants.PACKET_SIZE; i++)
                                                                                 //    PacketBufRX[i] = SPBuf[i];
                            sp = new serial_packet(SPBuf);

                            // Validate packet
                            if (ValidatePacket(ref sp))
                            {   // Send packet to main thread
                                pkg = new DataPkg(sp);
                                pkg.PkgNum = PkgNum++;
                                worker.ReportProgress(25, pkg);
                                synced = true;

                                if (SaveToFile && fs != null)
                                {
                                    // Prepare/append byte array to save
                                    if (FilePacketsPending == 0)
                                    { // Create new memory stream
                                        ms = new MemoryStream();
                                    }
                                    ms.Write(SPBuf, 0, (int)Constants.PACKET_SIZE);

                                    FilePacketsPending++;
                                    if (FilePacketsPending > 1000)
                                    {
                                        byte[] FilePacket = ms.ToArray();
                                        ms.Dispose();   // Clear memory
                                                        // Write byte array to file
                                                        //
                                                        //using ()
                                        writer.Write(FilePacket);

                                        FilePacketsPending = 0;
                                    }
                                }
                            }
                            else
                            {   // Try to find where the next packet starts in the buffer
                                for (i = 2; i < Constants.PACKET_SIZE; i++)
                                    if (PacketBufRX[i] == Constants.SIG_START_L)
                                        if (PacketBufRX[i + 1] == Constants.SIG_START_H)
                                            break;  // signature found
                                if (i < Constants.PACKET_SIZE)
                                {   // start signature was found - copy rest of the buffer to the beginning of the buffer
                                    PacketBufValidBytesRX = Constants.PACKET_SIZE - i;  // so many bytes to copy into the PacketBuf
                                    j = 0;
                                    for (; i < Constants.PACKET_SIZE; i++)
                                        PacketBufRX[j++] = PacketBufRX[i];
                                }
                                synced = false;
                            }
                        }
                        else
                        {   // If first part of a packet is available from the previous read - read the residual number 
                            SPort.Read(SPBuf, 0, (int)(Constants.PACKET_SIZE - PacketBufValidBytesRX)); // read number of bytes to exactly match one packet 
                                                                                                        // Copy packet into the packet buffer
                            for (i = 0; i < Constants.PACKET_SIZE - PacketBufValidBytesRX; i++)
                                PacketBufRX[PacketBufValidBytesRX + i] = SPBuf[i];

                            sp = new serial_packet(PacketBufRX);

                            // Validate packet
                            if (ValidatePacket(ref sp))
                            {
                                // Send packet to main thread
                                pkg = new DataPkg(sp);
                                pkg.PkgNum = PkgNum++;
                                worker.ReportProgress(25, pkg);
                                synced = true;

                                if (SaveToFile && fs != null)
                                {
                                    // Prepare/append byte array to save
                                    if (FilePacketsPending == 0)
                                    { // Create new memory stream
                                        ms = new MemoryStream();
                                    }
                                    ms.Write(SPBuf, 0, (int)Constants.PACKET_SIZE);


                                    FilePacketsPending++;
                                    if (FilePacketsPending > 1000)
                                    {
                                        byte[] FilePacket = ms.ToArray();
                                        ms.Dispose();   // Clear memory
                                                        // Write byte array to file
                                                        //
                                                        //using ()
                                        writer.Write(FilePacket);

                                        FilePacketsPending = 0;
                                    }
                                }

                            }
                            else
                            {   // Try to find where the next packet starts in the buffer
                                for (i = 2; i < Constants.PACKET_SIZE; i++)
                                    if (PacketBufRX[i] == Constants.SIG_START_L)
                                        //if (PacketBufRX[i + 1] == Constants.SIG_START_H)
                                        break;  // signature found
                                if (i < Constants.PACKET_SIZE)
                                {   // start signature was found - copy rest of the buffer to the beginning of the buffer
                                    PacketBufValidBytesRX = Constants.PACKET_SIZE - i;  // so many bytes to copy into the PacketBuf
                                    j = 0;
                                    for (; i < Constants.PACKET_SIZE; i++)
                                        PacketBufRX[j++] = PacketBufRX[i];
                                }
                            }
                        }
                    }
                    // Check queue for commands
                    lock (_lock)
                    {
                        if (CommQueue.Count != 0)
                        {   // Pop next command packet from queue
                            serial_packet sp_tx = CommQueue.Dequeue();
                            sp_tx.cnt = PktNum;
                            sp_tx.sig_start = Constants.SIG_START;
                            // Copy packet to output buffer
                            sp_tx.crc = sp_tx.CalcPacketCRC();
                            PacketBufTX = sp_tx.ToByteArray();
                            // Send packet to UART
                            SPort.Write(PacketBufTX, 0, (int)Constants.PACKET_SIZE);
                        }
                    }
                    if (worker.CancellationPending)
                    {
                        SPort.Close();
                        pkg = new DataPkg(PacketBufRX);
                        pkg.LastPkg = true;
                        worker.ReportProgress(100, pkg);
                        e.Cancel = true;
                        return;
                    }
                    Thread.Sleep(1);
                }
            }
            catch (Exception ex)
            {
                worker.ReportProgress(0, ex);
                e.Cancel = true;
                if (fs != null) fs.Close();
                return;
            }
        }

       private void bnMotorStop_Click(object sender, EventArgs e)
        {
            // Stop driving motor
            serial_packet sp_tx = new serial_packet();
            sp_tx.cmd = Constants.PC_CMD_STOP_MOTOR;

            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }
/*
        private void bnMotorDrive_Click(object sender, EventArgs e)
        {
            // Drive motor
            serial_packet sp_tx = new serial_packet();
            sp_tx.id = Constants.PT_CMD;
            sp_tx.cmd_status = Constants.PC_CMD_CL_SET_MOTOR_PARAMS;

            sp_tx.data[0] = (ushort)((rbMotorCtlModePosition.Checked) ? 0 : 1);  // Motor speed selector: 0 - motor controlled by pressure control block output; 1 - constant motor speed selected
            sp_tx.data[1] = (ushort)((rbMotorSpeedUnlock.Checked) ? 2048 - nudMotorSpeed.Value : 2048 + nudMotorSpeed.Value);  // Motor speed 
            sp_tx.data[2] = (ushort)(((cbMotorDriveHESLimit.Checked)? 1 : 0));

            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }

 */
        private void bnStartDAQ_Click(object sender, EventArgs e)
        {
            serial_packet sp_tx = new serial_packet();

            if ((string)bnStart.Tag == "0")
            {
                sp_tx.cmd = Constants.PC_CMD_OPERATION_ENABLE;

                bnStart.Tag = "1";
                bnStart.Text = "STOP";
                bnStart.BackColor = Color.Red;
            }
            else
            {
                sp_tx.cmd = Constants.PC_CMD_OPERATION_DISABLE;
                bnStart.Tag = "0";
                bnStart.Text = "START";
                bnStart.BackColor = Color.ForestGreen;
            }
            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }
        

        private void chGraph1_MouseDown(object sender, MouseEventArgs e)
        {
            var result = chGraph1.HitTest(e.X, e.Y, ChartElementType.DataPoint);
            if (result.ChartElementType == ChartElementType.DataPoint)
            {
                var prop = result.Object as DataPoint;
                if (prop != null)
                {
                    /*prop.IsValueShownAsLabel = true;
                    prop.MarkerStyle = MarkerStyle.Star4;*/
                    //int GraphNum = (int)nudGraphNum.Value;
                    lbCursorX.Text = result.Series.Points[result.PointIndex].XValue.ToString("F"); //result.PointIndex.ToString();
                    lbCursorY.Text = result.Series.Points[result.PointIndex].YValues[0].ToString("F"); //chGraph1.Series[GraphNum].Points[result.PointIndex].YValues[0].ToString("F");
                }
            }
        }
        private void bnSetMotorSpeedLow_Click(object sender, EventArgs e)
        {
            // Set motor speed LOW
            serial_packet sp_tx = new serial_packet();
            sp_tx.cmd = Constants.PC_CMD_SET_MOTOR_SPEED;
            sp_tx.data[0] = 0;
                        
            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }

        private void bnSetMotorSpeedHigh_Click(object sender, EventArgs e)
        {
            // Set motor speed HIGH
            serial_packet sp_tx = new serial_packet();
            sp_tx.cmd = Constants.PC_CMD_SET_MOTOR_SPEED;
            sp_tx.data[0] = 1;

            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }

        private void bnSetZeroPressure_Click(object sender, EventArgs e)
        {
            ZeroPressure_ADC = LastMeanValue;
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            lbRPMRequest.Text = tbSetRPM.Value.ToString();  
        }

        private void bnSetRepirationsPerMinute_Click(object sender, EventArgs e)
        {
            // Set new RPM value
            serial_packet sp_tx = new serial_packet();
            sp_tx.cmd = Constants.PC_CMD_SET_RPM;
            sp_tx.data[0] = (ushort)int.Parse(lbRPMRequest.Text);
            
            lock (_lock)
            {
                CommQueue.Enqueue(sp_tx);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tbLog.AppendText("Device connected\r\n");
            tbLog.AppendText("AC operation started\r\n");
            tbLog.AppendText("ALARM: PRESSURE LOSS!\r\n");
            tbLog.BackColor = Color.Red;
            tbLog.ForeColor = Color.Yellow;
            chGraph1.BackColor = Color.Red;

            Random rnd = new Random();

            double[] TEmp = new double[1000];
            for (int i = 0; i < 1000; i++)
            {
                TEmp[i] = ((double)rnd.Next(40, 60)) / 10;
                chGraph1.Series[0].Points.AddY(TEmp[i]);
            }

            bnConnectCOM.Text = "DISCONNECT";
        }
    }
}
