﻿namespace DataAcquisition
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.LegendCellColumn legendCellColumn11 = new System.Windows.Forms.DataVisualization.Charting.LegendCellColumn();
            System.Windows.Forms.DataVisualization.Charting.LegendCellColumn legendCellColumn12 = new System.Windows.Forms.DataVisualization.Charting.LegendCellColumn();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.bwCOM = new System.ComponentModel.BackgroundWorker();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bnSetMotorSpeedHigh = new System.Windows.Forms.Button();
            this.bnSetMotorSpeedLow = new System.Windows.Forms.Button();
            this.tbPacketsRcvd = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbRPMRequest = new System.Windows.Forms.Label();
            this.bnSetRepirationsPerMinute = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSetRPM = new System.Windows.Forms.TrackBar();
            this.bnConnectCOM = new System.Windows.Forms.Button();
            this.bnStart = new System.Windows.Forms.Button();
            this.tbLog = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lbCursorY = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.lbCursorX = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.bnSetAdaptiveYScale = new System.Windows.Forms.Button();
            this.bnSetGraphScales = new System.Windows.Forms.Button();
            this.nudGraph1Min = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.nudGraph1Max = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.chGraph1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.bnSetZeroPressure = new System.Windows.Forms.Button();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tbCOMPort = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetRPM)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudGraph1Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGraph1Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chGraph1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // bwCOM
            // 
            this.bwCOM.WorkerReportsProgress = true;
            this.bwCOM.WorkerSupportsCancellation = true;
            this.bwCOM.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwCOM_DoWork);
            this.bwCOM.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bw_ProgressChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.chGraph1, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 74F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1200, 530);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.tbPacketsRcvd);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.bnConnectCOM);
            this.panel1.Controls.Add(this.bnStart);
            this.panel1.Controls.Add(this.tbLog);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.tableLayoutPanel1.SetRowSpan(this.panel1, 2);
            this.panel1.Size = new System.Drawing.Size(294, 524);
            this.panel1.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Location = new System.Drawing.Point(170, 202);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(115, 79);
            this.groupBox6.TabIndex = 163;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "RPM MEASURED";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(24, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 46);
            this.label4.TabIndex = 140;
            this.label4.Text = "12";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(138, 502);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 152;
            this.label3.Text = "Data received:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.bnSetMotorSpeedHigh);
            this.groupBox3.Controls.Add(this.bnSetMotorSpeedLow);
            this.groupBox3.Location = new System.Drawing.Point(141, 372);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(144, 109);
            this.groupBox3.TabIndex = 158;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "INSPIRATORY FLOW";
            // 
            // bnSetMotorSpeedHigh
            // 
            this.bnSetMotorSpeedHigh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnSetMotorSpeedHigh.Location = new System.Drawing.Point(23, 58);
            this.bnSetMotorSpeedHigh.Name = "bnSetMotorSpeedHigh";
            this.bnSetMotorSpeedHigh.Size = new System.Drawing.Size(98, 36);
            this.bnSetMotorSpeedHigh.TabIndex = 139;
            this.bnSetMotorSpeedHigh.Tag = "0";
            this.bnSetMotorSpeedHigh.Text = "57 L/MIN";
            this.bnSetMotorSpeedHigh.UseVisualStyleBackColor = true;
            this.bnSetMotorSpeedHigh.Click += new System.EventHandler(this.bnSetMotorSpeedHigh_Click);
            // 
            // bnSetMotorSpeedLow
            // 
            this.bnSetMotorSpeedLow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnSetMotorSpeedLow.Location = new System.Drawing.Point(23, 19);
            this.bnSetMotorSpeedLow.Name = "bnSetMotorSpeedLow";
            this.bnSetMotorSpeedLow.Size = new System.Drawing.Size(98, 33);
            this.bnSetMotorSpeedLow.TabIndex = 138;
            this.bnSetMotorSpeedLow.Tag = "0";
            this.bnSetMotorSpeedLow.Text = "44 L/MIN";
            this.bnSetMotorSpeedLow.UseVisualStyleBackColor = true;
            this.bnSetMotorSpeedLow.Click += new System.EventHandler(this.bnSetMotorSpeedLow_Click);
            // 
            // tbPacketsRcvd
            // 
            this.tbPacketsRcvd.Location = new System.Drawing.Point(220, 499);
            this.tbPacketsRcvd.Name = "tbPacketsRcvd";
            this.tbPacketsRcvd.Size = new System.Drawing.Size(71, 20);
            this.tbPacketsRcvd.TabIndex = 151;
            this.tbPacketsRcvd.Text = "---";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(170, 287);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(115, 79);
            this.groupBox2.TabIndex = 157;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PEAK PRESSURE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 46);
            this.label2.TabIndex = 140;
            this.label2.Text = "25.4";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbRPMRequest);
            this.groupBox1.Controls.Add(this.bnSetRepirationsPerMinute);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbSetRPM);
            this.groupBox1.Location = new System.Drawing.Point(7, 201);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(74, 240);
            this.groupBox1.TabIndex = 156;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SET RPM";
            // 
            // lbRPMRequest
            // 
            this.lbRPMRequest.AutoSize = true;
            this.lbRPMRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbRPMRequest.Location = new System.Drawing.Point(21, 171);
            this.lbRPMRequest.Name = "lbRPMRequest";
            this.lbRPMRequest.Size = new System.Drawing.Size(34, 25);
            this.lbRPMRequest.TabIndex = 142;
            this.lbRPMRequest.Text = "12";
            // 
            // bnSetRepirationsPerMinute
            // 
            this.bnSetRepirationsPerMinute.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnSetRepirationsPerMinute.Location = new System.Drawing.Point(12, 200);
            this.bnSetRepirationsPerMinute.Name = "bnSetRepirationsPerMinute";
            this.bnSetRepirationsPerMinute.Size = new System.Drawing.Size(50, 33);
            this.bnSetRepirationsPerMinute.TabIndex = 141;
            this.bnSetRepirationsPerMinute.Tag = "0";
            this.bnSetRepirationsPerMinute.Text = "SET";
            this.bnSetRepirationsPerMinute.UseVisualStyleBackColor = true;
            this.bnSetRepirationsPerMinute.Click += new System.EventHandler(this.bnSetRepirationsPerMinute_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(5, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 46);
            this.label1.TabIndex = 140;
            this.label1.Text = "12";
            // 
            // tbSetRPM
            // 
            this.tbSetRPM.Location = new System.Drawing.Point(15, 55);
            this.tbSetRPM.Maximum = 40;
            this.tbSetRPM.Minimum = 5;
            this.tbSetRPM.Name = "tbSetRPM";
            this.tbSetRPM.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbSetRPM.Size = new System.Drawing.Size(45, 121);
            this.tbSetRPM.TabIndex = 0;
            this.tbSetRPM.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbSetRPM.Value = 12;
            this.tbSetRPM.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // bnConnectCOM
            // 
            this.bnConnectCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnConnectCOM.Location = new System.Drawing.Point(7, 3);
            this.bnConnectCOM.Name = "bnConnectCOM";
            this.bnConnectCOM.Size = new System.Drawing.Size(130, 32);
            this.bnConnectCOM.TabIndex = 154;
            this.bnConnectCOM.Tag = "0";
            this.bnConnectCOM.Text = "CONNECT";
            this.bnConnectCOM.UseVisualStyleBackColor = true;
            this.bnConnectCOM.Click += new System.EventHandler(this.bnConnectCOM_Click);
            // 
            // bnStart
            // 
            this.bnStart.BackColor = System.Drawing.Color.ForestGreen;
            this.bnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnStart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bnStart.Location = new System.Drawing.Point(7, 140);
            this.bnStart.Name = "bnStart";
            this.bnStart.Size = new System.Drawing.Size(278, 58);
            this.bnStart.TabIndex = 151;
            this.bnStart.Tag = "0";
            this.bnStart.Text = "START";
            this.bnStart.UseVisualStyleBackColor = false;
            this.bnStart.Click += new System.EventHandler(this.bnStartDAQ_Click);
            // 
            // tbLog
            // 
            this.tbLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbLog.Location = new System.Drawing.Point(7, 36);
            this.tbLog.Multiline = true;
            this.tbLog.Name = "tbLog";
            this.tbLog.Size = new System.Drawing.Size(278, 102);
            this.tbLog.TabIndex = 74;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.groupBox10);
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(303, 459);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(894, 68);
            this.panel2.TabIndex = 77;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lbCursorY);
            this.groupBox10.Controls.Add(this.label64);
            this.groupBox10.Controls.Add(this.lbCursorX);
            this.groupBox10.Controls.Add(this.label66);
            this.groupBox10.Location = new System.Drawing.Point(262, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(191, 60);
            this.groupBox10.TabIndex = 161;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Cursor values";
            // 
            // lbCursorY
            // 
            this.lbCursorY.AutoSize = true;
            this.lbCursorY.Location = new System.Drawing.Point(116, 16);
            this.lbCursorY.Name = "lbCursorY";
            this.lbCursorY.Size = new System.Drawing.Size(46, 13);
            this.lbCursorY.TabIndex = 141;
            this.lbCursorY.Text = "-------------";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.Color.Black;
            this.label64.Location = new System.Drawing.Point(95, 16);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(17, 13);
            this.label64.TabIndex = 140;
            this.label64.Text = "Y:";
            // 
            // lbCursorX
            // 
            this.lbCursorX.AutoSize = true;
            this.lbCursorX.Location = new System.Drawing.Point(33, 19);
            this.lbCursorX.Name = "lbCursorX";
            this.lbCursorX.Size = new System.Drawing.Size(46, 13);
            this.lbCursorX.TabIndex = 139;
            this.lbCursorX.Text = "-------------";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(13, 18);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(17, 13);
            this.label66.TabIndex = 138;
            this.label66.Text = "X:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.bnSetAdaptiveYScale);
            this.groupBox5.Controls.Add(this.bnSetGraphScales);
            this.groupBox5.Controls.Add(this.nudGraph1Min);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.nudGraph1Max);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Location = new System.Drawing.Point(3, 1);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(252, 64);
            this.groupBox5.TabIndex = 149;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Graph parameters";
            // 
            // bnSetAdaptiveYScale
            // 
            this.bnSetAdaptiveYScale.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bnSetAdaptiveYScale.Location = new System.Drawing.Point(164, 35);
            this.bnSetAdaptiveYScale.Name = "bnSetAdaptiveYScale";
            this.bnSetAdaptiveYScale.Size = new System.Drawing.Size(80, 23);
            this.bnSetAdaptiveYScale.TabIndex = 153;
            this.bnSetAdaptiveYScale.Tag = "1";
            this.bnSetAdaptiveYScale.Text = "Set adaptive";
            this.bnSetAdaptiveYScale.UseVisualStyleBackColor = true;
            this.bnSetAdaptiveYScale.Click += new System.EventHandler(this.bnSetAdaptiveYScale_Click);
            // 
            // bnSetGraphScales
            // 
            this.bnSetGraphScales.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bnSetGraphScales.Location = new System.Drawing.Point(95, 35);
            this.bnSetGraphScales.Name = "bnSetGraphScales";
            this.bnSetGraphScales.Size = new System.Drawing.Size(68, 23);
            this.bnSetGraphScales.TabIndex = 148;
            this.bnSetGraphScales.Tag = "1";
            this.bnSetGraphScales.Text = "Set manual";
            this.bnSetGraphScales.UseVisualStyleBackColor = true;
            this.bnSetGraphScales.Click += new System.EventHandler(this.bnSetGraphScales_Click);
            // 
            // nudGraph1Min
            // 
            this.nudGraph1Min.Location = new System.Drawing.Point(45, 37);
            this.nudGraph1Min.Maximum = new decimal(new int[] {
            66000,
            0,
            0,
            0});
            this.nudGraph1Min.Minimum = new decimal(new int[] {
            66000,
            0,
            0,
            -2147483648});
            this.nudGraph1Min.Name = "nudGraph1Min";
            this.nudGraph1Min.Size = new System.Drawing.Size(50, 20);
            this.nudGraph1Min.TabIndex = 144;
            this.nudGraph1Min.Value = new decimal(new int[] {
            30,
            0,
            0,
            -2147483648});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(4, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 147;
            this.label8.Text = "Y max:";
            // 
            // nudGraph1Max
            // 
            this.nudGraph1Max.Location = new System.Drawing.Point(45, 16);
            this.nudGraph1Max.Maximum = new decimal(new int[] {
            66000,
            0,
            0,
            0});
            this.nudGraph1Max.Minimum = new decimal(new int[] {
            66000,
            0,
            0,
            -2147483648});
            this.nudGraph1Max.Name = "nudGraph1Max";
            this.nudGraph1Max.Size = new System.Drawing.Size(50, 20);
            this.nudGraph1Max.TabIndex = 145;
            this.nudGraph1Max.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(4, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 146;
            this.label7.Text = "Y min:";
            // 
            // chGraph1
            // 
            chartArea6.AxisY.Maximum = 60D;
            chartArea6.AxisY.Minimum = -30D;
            chartArea6.BorderWidth = 2;
            chartArea6.Name = "ChartArea1";
            this.chGraph1.ChartAreas.Add(chartArea6);
            this.chGraph1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend6.Alignment = System.Drawing.StringAlignment.Center;
            legendCellColumn11.Name = "Column1";
            legendCellColumn12.ColumnType = System.Windows.Forms.DataVisualization.Charting.LegendCellColumnType.SeriesSymbol;
            legendCellColumn12.Name = "Column2";
            legend6.CellColumns.Add(legendCellColumn11);
            legend6.CellColumns.Add(legendCellColumn12);
            legend6.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend6.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Row;
            legend6.Name = "Legend1";
            this.chGraph1.Legends.Add(legend6);
            this.chGraph1.Location = new System.Drawing.Point(303, 3);
            this.chGraph1.Name = "chGraph1";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series6.Legend = "Legend1";
            series6.Name = "Airway pressure, cm H2O";
            this.chGraph1.Series.Add(series6);
            this.chGraph1.Size = new System.Drawing.Size(894, 450);
            this.chGraph1.TabIndex = 76;
            this.chGraph1.Text = "Graph 1";
            this.chGraph1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.chGraph1_MouseDown);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1214, 562);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1206, 536);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.checkBox4);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.checkBox3);
            this.tabPage2.Controls.Add(this.checkBox2);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.trackBar4);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.checkBox1);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.trackBar3);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.trackBar2);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1206, 536);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Setup";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox2.Location = new System.Drawing.Point(661, 128);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(84, 24);
            this.checkBox2.TabIndex = 179;
            this.checkBox2.Text = "ALARM";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(540, 80);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 25);
            this.label19.TabIndex = 178;
            this.label19.Text = "cm H2O";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.SkyBlue;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(382, 393);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 46);
            this.label17.TabIndex = 177;
            this.label17.Text = "10";
            // 
            // trackBar4
            // 
            this.trackBar4.Location = new System.Drawing.Point(258, 393);
            this.trackBar4.Maximum = 12;
            this.trackBar4.Minimum = 5;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Size = new System.Drawing.Size(121, 45);
            this.trackBar4.TabIndex = 176;
            this.trackBar4.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar4.Value = 10;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(22, 399);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(231, 25);
            this.label18.TabIndex = 175;
            this.label18.Text = "Battery low level warning:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox1.Location = new System.Drawing.Point(661, 83);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(84, 24);
            this.checkBox1.TabIndex = 174;
            this.checkBox1.Text = "ALARM";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.SkyBlue;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(471, 69);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 46);
            this.label15.TabIndex = 173;
            this.label15.Text = "40";
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(347, 69);
            this.trackBar3.Maximum = 40;
            this.trackBar3.Minimum = 5;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(121, 45);
            this.trackBar3.TabIndex = 172;
            this.trackBar3.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar3.Value = 40;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(22, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(320, 25);
            this.label16.TabIndex = 171;
            this.label16.Text = "Emergency STOP airway pressure:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.SkyBlue;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(471, 119);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 46);
            this.label14.TabIndex = 170;
            this.label14.Text = "25";
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(347, 119);
            this.trackBar2.Maximum = 40;
            this.trackBar2.Minimum = 5;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(121, 45);
            this.trackBar2.TabIndex = 169;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar2.Value = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(22, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 25);
            this.label13.TabIndex = 168;
            this.label13.Text = "Peak airway pressure:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(147, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(201, 25);
            this.label12.TabIndex = 166;
            this.label12.Text = "Operation parameters";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.tbCOMPort);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.bnSetZeroPressure);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1206, 536);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Service";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(325, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 25);
            this.label11.TabIndex = 170;
            this.label11.Text = "4.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(325, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 25);
            this.label10.TabIndex = 169;
            this.label10.Text = "2.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(17, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(295, 25);
            this.label9.TabIndex = 168;
            this.label9.Text = "3. Connect calibration adapter ->";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(17, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(234, 25);
            this.label6.TabIndex = 167;
            this.label6.Text = "1. Open airway system ->";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(356, 106);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 35);
            this.button1.TabIndex = 166;
            this.button1.Tag = "1";
            this.button1.Text = "Calibrate";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(196, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 25);
            this.label5.TabIndex = 165;
            this.label5.Text = "Calibration";
            // 
            // bnSetZeroPressure
            // 
            this.bnSetZeroPressure.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bnSetZeroPressure.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bnSetZeroPressure.Location = new System.Drawing.Point(356, 65);
            this.bnSetZeroPressure.Name = "bnSetZeroPressure";
            this.bnSetZeroPressure.Size = new System.Drawing.Size(187, 35);
            this.bnSetZeroPressure.TabIndex = 164;
            this.bnSetZeroPressure.Tag = "1";
            this.bnSetZeroPressure.Text = "Set zero pressure";
            this.bnSetZeroPressure.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox3.Location = new System.Drawing.Point(27, 193);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(222, 24);
            this.checkBox3.TabIndex = 181;
            this.checkBox3.Text = "System disconnect ALARM";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(541, 125);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 25);
            this.label20.TabIndex = 182;
            this.label20.Text = "cm H2O";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(457, 404);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 25);
            this.label21.TabIndex = 183;
            this.label21.Text = "Volts";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox4.Location = new System.Drawing.Point(27, 453);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(216, 24);
            this.checkBox4.TabIndex = 184;
            this.checkBox4.Text = "Mains Power Loss ALARM";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(435, 479);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 171;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(196, 214);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 25);
            this.label22.TabIndex = 173;
            this.label22.Text = "Connectivity";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(18, 259);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(175, 25);
            this.label23.TabIndex = 174;
            this.label23.Text = "COM port number:";
            // 
            // tbCOMPort
            // 
            this.tbCOMPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbCOMPort.Location = new System.Drawing.Point(199, 260);
            this.tbCOMPort.Name = "tbCOMPort";
            this.tbCOMPort.Size = new System.Drawing.Size(76, 26);
            this.tbCOMPort.TabIndex = 175;
            this.tbCOMPort.Text = "COM3";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(279, 260);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(72, 26);
            this.button3.TabIndex = 176;
            this.button3.Tag = "1";
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(781, 78);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 33);
            this.button4.TabIndex = 185;
            this.button4.Tag = "0";
            this.button4.Text = "SET";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(781, 123);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 33);
            this.button5.TabIndex = 186;
            this.button5.Tag = "0";
            this.button5.Text = "SET";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.Location = new System.Drawing.Point(533, 402);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 33);
            this.button6.TabIndex = 187;
            this.button6.Tag = "0";
            this.button6.Text = "SET";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.Location = new System.Drawing.Point(258, 188);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 33);
            this.button7.TabIndex = 188;
            this.button7.Tag = "0";
            this.button7.Text = "SET";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 562);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Text = "VentUI 1.0";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetRPM)).EndInit();
            this.panel2.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudGraph1Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudGraph1Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chGraph1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.ComponentModel.BackgroundWorker bwCOM;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chGraph1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bnConnectCOM;
        private System.Windows.Forms.Button bnStart;
        private System.Windows.Forms.TextBox tbLog;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label lbCursorY;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label lbCursorX;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button bnSetAdaptiveYScale;
        private System.Windows.Forms.Button bnSetGraphScales;
        private System.Windows.Forms.NumericUpDown nudGraph1Min;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nudGraph1Max;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPacketsRcvd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar tbSetRPM;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button bnSetMotorSpeedHigh;
        private System.Windows.Forms.Button bnSetMotorSpeedLow;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bnSetZeroPressure;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TrackBar trackBar4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button bnSetRepirationsPerMinute;
        private System.Windows.Forms.Label lbRPMRequest;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox tbCOMPort;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
    }
}

